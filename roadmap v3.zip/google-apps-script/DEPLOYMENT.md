# Google Apps Script Deployment Settings

1. Open the Google Apps Script project
2. Click "Deploy" > "New deployment"
3. Select "Web app"
4. Configure the following settings:
   - Execute as: "Me"
   - Who has access: "Anyone"
   - Project version: "New"
5. Click "Deploy"
6. Authorize the application when prompted
7. Copy the new Web App URL and update your environment variables

Note: Make sure the Google Sheet:
- Is shared with the executing account
- Has a sheet named "Ideas" 
- Has the correct column headers: id, title, description, status, votes, authorId, createdAt

