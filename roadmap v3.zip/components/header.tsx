"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AuthModal } from "@/components/auth/auth-modal"
import { SearchBar } from "@/components/search-bar"
import { useAuth } from "@/lib/auth-context"
import { ArrowRight, LogOut } from "lucide-react"

export function Header() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <header className="border-b h-[60px]">
      <div className="container mx-auto h-full px-4">
        <div className="flex items-center justify-between h-full">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-semibold">R</span>
              </div>
              <span className="font-semibold">Roadmap</span>
            </Link>
            <nav className="flex items-center gap-6">
              <Link href="/ideas" className="text-muted-foreground hover:text-foreground">
                Ideas
              </Link>
              <Link href="/roadmap" className="text-muted-foreground hover:text-foreground">
                Roadmap
              </Link>
              <Link href="/announcements" className="text-muted-foreground hover:text-foreground">
                Announcements
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <SearchBar />
            {user ? (
              <>
                <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
                  Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={() => setShowAuthModal(true)}>
                  Log in
                </Button>
                <Button size="sm" onClick={() => setShowAuthModal(true)}>
                  Sign up
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </header>
  )
}

