"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { X } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

interface Activity {
  id: number
  type: "comment" | "status_change" | "update"
  content: string
  author: {
    name: string
    avatar?: string
  }
  createdAt: string
}

interface ActivityPanelProps {
  isOpen: boolean
  onClose: () => void
  ideaId: number | null
}

export function ActivityPanel({ isOpen, onClose, ideaId }: ActivityPanelProps) {
  const [activities, setActivities] = useState<Activity[]>([])
  const [comment, setComment] = useState("")
  const [idea, setIdea] = useState({
    title: "Best time to post",
    description:
      "Implement an AI-powered analytics feature that suggests the optimal posting times based on historical engagement data.",
    status: "in-progress",
  })

  useEffect(() => {
    if (ideaId) {
      // In a real app, fetch activities from your API
      const mockActivities: Activity[] = [
        {
          id: 1,
          type: "update",
          content:
            "Beta 2\ndecided to focus solely on improving our API.\n\nRegarding sending outgoing webhooks on certain events - still in consideration.",
          author: {
            name: "System",
            avatar: "/placeholder.svg?height=40&width=40",
          },
          createdAt: "2024-01-29",
        },
        {
          id: 2,
          type: "comment",
          content: "I specifically would like to see outgoing webhooks that are triggered when Ocoya posts.",
          author: {
            name: "Jacob P",
            avatar: "/placeholder.svg?height=40&width=40",
          },
          createdAt: "2024-01-28",
        },
        {
          id: 3,
          type: "status_change",
          content: "Status changed from 'Todo' to 'In Progress'",
          author: {
            name: "Admin",
            avatar: "/placeholder.svg?height=40&width=40",
          },
          createdAt: "2024-01-27",
        },
      ]
      setActivities(mockActivities)
    }
  }, [ideaId])

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!comment.trim()) return

    const newActivity: Activity = {
      id: Date.now(),
      type: "comment",
      content: comment,
      author: {
        name: "You",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      createdAt: new Date().toISOString().split("T")[0],
    }

    setActivities([newActivity, ...activities])
    setComment("")
  }

  return (
    <div
      className={cn(
        "fixed inset-y-0 right-0 w-[400px] bg-background border-l transform transition-transform duration-200 ease-in-out z-50",
        isOpen ? "translate-x-0" : "translate-x-full",
      )}
    >
      <div className="h-full flex flex-col">
        <div className="p-4 border-b flex items-center justify-between">
          <h2 className="text-lg font-semibold">Details</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">{idea.title}</h3>
            <p className="text-sm text-muted-foreground mb-4">{idea.description}</p>
            <Badge variant={idea.status === "done" ? "default" : "secondary"} className="capitalize">
              {idea.status}
            </Badge>
          </div>
          <Separator />
          <h4 className="font-medium">Activity</h4>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 space-y-6">
            {activities.map((activity) => (
              <div key={activity.id} className="space-y-2">
                <div className="flex items-start gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={activity.author.avatar} />
                    <AvatarFallback>{activity.author.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{activity.author.name}</span>
                      <span className="text-sm text-muted-foreground">
                        {new Date(activity.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-sm whitespace-pre-wrap">{activity.content}</div>
                  </div>
                </div>
                <Separator />
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="p-4 border-t">
          <form onSubmit={handleSubmitComment}>
            <div className="flex gap-2">
              <Input placeholder="Add a comment..." value={comment} onChange={(e) => setComment(e.target.value)} />
              <Button type="submit">Send</Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

