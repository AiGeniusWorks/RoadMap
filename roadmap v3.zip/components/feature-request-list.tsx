"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUp, MessageSquare } from "lucide-react"
import { getIdeas, updateIdea } from "@/lib/api-client"
import { toast } from "@/components/ui/use-toast"

interface FeatureRequest {
  id: string
  title: string
  description: string
  votes: number
  comments: number
  status: string
  author: string
  createdAt: string
}

interface FeatureRequestListProps {
  searchQuery: string
  statusFilter: string
  sortBy: string
}

export function FeatureRequestList({ searchQuery, statusFilter, sortBy }: FeatureRequestListProps) {
  const [requests, setRequests] = useState<FeatureRequest[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchIdeas() {
      setIsLoading(true)
      try {
        const ideas = await getIdeas()
        setRequests(ideas)
      } catch (error) {
        console.error("Failed to fetch ideas:", error)
        toast({
          title: "Error loading ideas",
          description: error instanceof Error ? error.message : "An unexpected error occurred",
          variant: "destructive",
        })
        setRequests([])
      } finally {
        setIsLoading(false)
      }
    }

    fetchIdeas()
  }, [])

  const handleVote = async (id: string) => {
    const idea = requests.find((r) => r.id === id)
    if (idea) {
      const updatedIdea = { ...idea, votes: idea.votes + 1 }
      try {
        await updateIdea(updatedIdea)
        setRequests(requests.map((r) => (r.id === id ? updatedIdea : r)))
      } catch (error) {
        console.error("Failed to update vote:", error)
        toast({
          title: "Error",
          description: "Failed to update vote. Please try again.",
          variant: "destructive",
        })
      }
    }
  }

  const filteredRequests = requests.filter((request) => {
    const matchesSearch =
      request.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || request.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const sortedRequests = [...filteredRequests].sort((a, b) => {
    if (sortBy === "votes") {
      return b.votes - a.votes
    } else if (sortBy === "recent") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    }
    return 0
  })

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-4">
      {sortedRequests.map((request) => (
        <Card key={request.id}>
          <CardHeader className="p-4">
            <div className="flex items-start gap-4">
              <div className="text-center">
                <button
                  className="flex flex-col items-center gap-0.5 text-sm text-muted-foreground hover:text-foreground"
                  onClick={() => handleVote(request.id)}
                >
                  <ArrowUp className="h-5 w-5" />
                  <span>{request.votes}</span>
                </button>
              </div>
              <div className="flex-1 space-y-1">
                <CardTitle className="text-xl">{request.title}</CardTitle>
                <p className="text-muted-foreground">{request.description}</p>
              </div>
              <Badge variant={request.status === "done" ? "default" : "secondary"} className="capitalize">
                {request.status}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="px-4 pb-4 pt-0">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>{request.author}</span>
              <span>•</span>
              <span>{new Date(request.createdAt).toLocaleDateString()}</span>
              <span>•</span>
              <div className="flex items-center gap-1">
                <MessageSquare className="h-4 w-4" />
                {request.comments}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

