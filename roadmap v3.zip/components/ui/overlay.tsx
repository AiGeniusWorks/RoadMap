import { cn } from "@/lib/utils"

interface OverlayProps {
  show: boolean
  onClick?: () => void
  className?: string
}

export function Overlay({ show, onClick, className }: OverlayProps) {
  return (
    <div
      className={cn(
        "fixed inset-0 bg-background/80 backdrop-blur-sm transition-all",
        show ? "opacity-100" : "opacity-0 pointer-events-none",
        className,
      )}
      onClick={onClick}
    />
  )
}

