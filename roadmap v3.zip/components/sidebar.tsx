import Link from "next/link"
import { MessageSquare, Clock, CheckCircle, XCircle, Inbox } from "lucide-react"
import { cn } from "@/lib/utils"

const statuses = [
  {
    label: "User Feedback / Ideas",
    icon: MessageSquare,
    href: "/ideas?status=feedback",
    count: 11,
    color: "text-yellow-600",
  },
  {
    label: "To Do",
    icon: Clock,
    href: "/ideas?status=todo",
    count: 6,
    color: "text-blue-600",
  },
  {
    label: "In Progress",
    icon: Inbox,
    href: "/ideas?status=in-progress",
    count: 16,
    color: "text-purple-600",
  },
  {
    label: "Done",
    icon: CheckCircle,
    href: "/ideas?status=done",
    count: 66,
    color: "text-green-600",
  },
  {
    label: "Rejected",
    icon: XCircle,
    href: "/ideas?status=rejected",
    count: 10,
    color: "text-red-600",
  },
]

export function Sidebar() {
  return (
    <div className="w-64 border-r p-4 space-y-4">
      <div className="font-medium px-2">Statuses</div>
      <nav className="space-y-1">
        {statuses.map((status) => (
          <Link
            key={status.label}
            href={status.href}
            className="flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted"
          >
            <status.icon className={cn("h-4 w-4", status.color)} />
            <span className="flex-1">{status.label}</span>
            <span className="text-xs bg-muted px-1.5 py-0.5 rounded-md">{status.count}</span>
          </Link>
        ))}
      </nav>
      <div className="font-medium px-2 pt-4">Topics</div>
      <nav className="space-y-1">
        <Link
          href="/ideas?topic=api"
          className="flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted"
        >
          API
        </Link>
        <Link
          href="/ideas?topic=mobile"
          className="flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted"
        >
          Mobile App
        </Link>
        <Link
          href="/ideas?topic=integrations"
          className="flex items-center gap-2 px-2 py-1.5 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted"
        >
          Integrations
        </Link>
      </nav>
    </div>
  )
}

