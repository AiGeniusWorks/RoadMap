"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowUp, MessageSquare } from "lucide-react"
import { ActivityPanel } from "@/components/activity-panel"

type Status = "feedback" | "todo" | "in-progress" | "done" | "rejected"

interface RoadmapItem {
  id: number
  title: string
  votes: number
  status: Status
  comments: { id: number; author: string; content: string }[]
}

const MOCK_ITEMS: RoadmapItem[] = [
  { id: 1, title: "Implement dark mode", votes: 15, status: "feedback", comments: [] },
  { id: 2, title: "Add CSV export", votes: 10, status: "feedback", comments: [] },
  { id: 3, title: "Integrate with Slack", votes: 8, status: "feedback", comments: [] },
  { id: 4, title: "Create mobile app", votes: 20, status: "feedback", comments: [] },
  { id: 5, title: "Improve search functionality", votes: 12, status: "feedback", comments: [] },
  { id: 6, title: "Implement user roles", votes: 18, status: "todo", comments: [] },
  { id: 7, title: "Add two-factor authentication", votes: 14, status: "todo", comments: [] },
  { id: 8, title: "Create API documentation", votes: 9, status: "todo", comments: [] },
  { id: 9, title: "Implement file uploads", votes: 11, status: "todo", comments: [] },
  { id: 10, title: "Add email notifications", votes: 16, status: "todo", comments: [] },
  { id: 11, title: "Redesign dashboard", votes: 22, status: "in-progress", comments: [] },
  { id: 12, title: "Optimize database queries", votes: 13, status: "in-progress", comments: [] },
  { id: 13, title: "Implement real-time updates", votes: 19, status: "in-progress", comments: [] },
  { id: 14, title: "Add multi-language support", votes: 17, status: "in-progress", comments: [] },
  { id: 15, title: "Create onboarding tutorial", votes: 15, status: "in-progress", comments: [] },
  { id: 16, title: "Launch beta version", votes: 25, status: "done", comments: [] },
  { id: 17, title: "Implement user authentication", votes: 20, status: "done", comments: [] },
  { id: 18, title: "Create landing page", votes: 18, status: "done", comments: [] },
  { id: 19, title: "Set up CI/CD pipeline", votes: 16, status: "done", comments: [] },
  { id: 20, title: "Implement basic CRUD operations", votes: 22, status: "done", comments: [] },
  { id: 21, title: "Add blockchain integration", votes: 7, status: "rejected", comments: [] },
  { id: 22, title: "Implement VR interface", votes: 5, status: "rejected", comments: [] },
  { id: 23, title: "Create desktop application", votes: 9, status: "rejected", comments: [] },
  { id: 24, title: "Add voice commands", votes: 6, status: "rejected", comments: [] },
  { id: 25, title: "Implement AI chatbot", votes: 8, status: "rejected", comments: [] },
]

const STATUS_COLUMNS: { title: string; status: Status; color: string }[] = [
  { title: "User Feedback / Ideas", status: "feedback", color: "bg-yellow-100" },
  { title: "To Do", status: "todo", color: "bg-blue-100" },
  { title: "In Progress", status: "in-progress", color: "bg-purple-100" },
  { title: "Done", status: "done", color: "bg-green-100" },
  { title: "Rejected", status: "rejected", color: "bg-red-100" },
]

export function RoadmapBoard() {
  const [items, setItems] = useState(MOCK_ITEMS)
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null)

  const handleVote = (id: number, e: React.MouseEvent) => {
    e.stopPropagation() // Prevent card click when voting
    setItems(items.map((item) => (item.id === id ? { ...item, votes: item.votes + 1 } : item)))
  }

  const handleCardClick = (id: number) => {
    setSelectedItemId(id)
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {STATUS_COLUMNS.map((column) => (
          <div key={column.status} className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold">{column.title}</h3>
              <Badge variant="secondary">{items.filter((item) => item.status === column.status).length}</Badge>
            </div>
            <div className="space-y-4">
              {items
                .filter((item) => item.status === column.status)
                .map((item) => (
                  <Card
                    key={item.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => handleCardClick(item.id)}
                  >
                    <CardHeader className="p-3">
                      <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0">
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <Button variant="ghost" size="sm" className="p-0" onClick={(e) => handleVote(item.id, e)}>
                          <ArrowUp className="h-4 w-4 mr-1" />
                          {item.votes}
                        </Button>
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" />
                          {item.comments?.length || 0}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        ))}
      </div>

      <ActivityPanel isOpen={selectedItemId !== null} onClose={() => setSelectedItemId(null)} ideaId={selectedItemId} />
    </>
  )
}

