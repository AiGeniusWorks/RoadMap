"use client"

import { useState } from "react"
import { ArrowUp, MessageSquare, Share2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

interface IdeaDetailsProps {
  idea: {
    id: string
    title: string
    description: string
    votes: number
    status: string
    author: string
    date: string
  }
}

export function IdeaDetails({ idea }: IdeaDetailsProps) {
  const [votes, setVotes] = useState(idea.votes)
  const [hasVoted, setHasVoted] = useState(false)

  const handleVote = () => {
    if (hasVoted) {
      setVotes(votes - 1)
      setHasVoted(false)
    } else {
      setVotes(votes + 1)
      setHasVoted(true)
    }
  }

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      toast({
        description: "Link copied to clipboard",
      })
    } catch (err) {
      toast({
        variant: "destructive",
        description: "Failed to copy link",
      })
    }
  }

  return (
    <Card>
      <CardHeader className="space-y-4">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold">{idea.title}</h2>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>{idea.author}</span>
              <span>•</span>
              <span>{idea.date}</span>
            </div>
          </div>
          <Badge variant={idea.status === "done" ? "default" : "secondary"} className="capitalize">
            {idea.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground whitespace-pre-wrap">{idea.description}</p>
      </CardContent>
      <CardFooter>
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            className={`flex items-center gap-1 ${hasVoted ? "text-primary" : ""}`}
            onClick={handleVote}
          >
            <ArrowUp className="h-4 w-4" />
            <span>{votes}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="flex items-center gap-1"
            onClick={() => document.getElementById("comment-input")?.focus()}
          >
            <MessageSquare className="h-4 w-4" />
            <span>Comment</span>
          </Button>
          <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleShare}>
            <Share2 className="h-4 w-4" />
            <span>Share</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

