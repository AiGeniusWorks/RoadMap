"use client"

import { useState, useEffect } from "react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Search } from "lucide-react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

interface SearchResult {
  id: number
  title: string
  status: string
  type: "idea" | "announcement"
}

export function SearchBar() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const router = useRouter()

  useEffect(() => {
    if (!open) {
      setQuery("")
    }
  }, [open])

  useEffect(() => {
    if (query.length === 0) {
      setResults([])
      return
    }

    // Simulate API call
    const mockResults: SearchResult[] = [
      { id: 1, title: "Dark Mode Implementation", status: "in-progress", type: "idea" },
      { id: 2, title: "Mobile App Development", status: "todo", type: "idea" },
      { id: 3, title: "New Feature Release", status: "done", type: "announcement" },
    ].filter(
      (item) =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.status.toLowerCase().includes(query.toLowerCase()),
    )

    setResults(mockResults)
  }, [query])

  const handleSelect = (result: SearchResult) => {
    setOpen(false)
    if (result.type === "idea") {
      router.push(`/ideas/${result.id}`)
    } else {
      router.push(`/announcements`)
    }
  }

  return (
    <>
      <Button
        variant="outline"
        className="relative h-9 w-9 p-0 xl:h-10 xl:w-60 xl:justify-start xl:px-3 xl:py-2"
        onClick={() => setOpen(true)}
      >
        <Search className="h-4 w-4 xl:mr-2" />
        <span className="hidden xl:inline-flex">Search ideas...</span>
        <span className="sr-only">Search ideas</span>
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="p-0">
          <Command>
            <CommandInput placeholder="Search ideas..." value={query} onValueChange={setQuery} />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Ideas">
                {results
                  .filter((result) => result.type === "idea")
                  .map((result) => (
                    <CommandItem key={result.id} value={result.title} onSelect={() => handleSelect(result)}>
                      <div className="flex items-center">
                        <span>{result.title}</span>
                        <span className="ml-2 rounded-full px-2 py-0.5 text-xs bg-muted">{result.status}</span>
                      </div>
                    </CommandItem>
                  ))}
              </CommandGroup>
              <CommandGroup heading="Announcements">
                {results
                  .filter((result) => result.type === "announcement")
                  .map((result) => (
                    <CommandItem key={result.id} value={result.title} onSelect={() => handleSelect(result)}>
                      {result.title}
                    </CommandItem>
                  ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </DialogContent>
      </Dialog>
    </>
  )
}

