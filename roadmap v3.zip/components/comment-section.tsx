"use client"

import type React from "react"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"

// This would come from your database
const MOCK_COMMENTS = [
  {
    id: 1,
    author: "Sarah Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "This would be incredibly useful! Looking forward to seeing this implemented.",
    date: "2 hours ago",
  },
  {
    id: 2,
    author: "Alex Thompson",
    avatar: "/placeholder.svg?height=40&width=40",
    content: "Great idea! Would it also consider timezone differences for global audience?",
    date: "5 hours ago",
  },
]

interface CommentSectionProps {
  ideaId: string
}

export function CommentSection({ ideaId }: CommentSectionProps) {
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!comment.trim()) return

    setIsSubmitting(true)
    // Here you would typically send the comment to your API
    await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate API call
    setIsSubmitting(false)
    setComment("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Comments</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            id="comment-input"
            placeholder="Share your thoughts..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <div className="flex justify-end">
            <Button type="submit" disabled={!comment.trim() || isSubmitting}>
              {isSubmitting ? "Posting..." : "Post Comment"}
            </Button>
          </div>
        </form>
        <div className="space-y-6">
          {MOCK_COMMENTS.map((comment) => (
            <div key={comment.id} className="flex gap-4">
              <Avatar>
                <AvatarImage src={comment.avatar} alt={comment.author} />
                <AvatarFallback>{comment.author[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{comment.author}</span>
                  <span className="text-sm text-muted-foreground">{comment.date}</span>
                </div>
                <p className="text-muted-foreground">{comment.content}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

