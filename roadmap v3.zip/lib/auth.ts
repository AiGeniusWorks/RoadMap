import { type NextRequest, NextResponse } from "next/server"

export function isAdmin(request: NextRequest) {
  const authHeader = request.headers.get("authorization")
  if (authHeader === "Basic Y2FsbEBhaWdlbml1cy5zcGFjZTpWaWJlQ29kZXI=") {
    return true
  }
  return false
}

export function authMiddleware(request: NextRequest) {
  if (!isAdmin(request)) {
    return new NextResponse(JSON.stringify({ success: false, message: "authentication failed" }), {
      status: 401,
      headers: { "content-type": "application/json" },
    })
  }
}

