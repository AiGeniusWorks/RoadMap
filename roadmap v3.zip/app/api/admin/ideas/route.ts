import { type NextRequest, NextResponse } from "next/server"
import { authMiddleware } from "@/lib/auth"

const MOCK_IDEAS = [
  { id: 1, title: "Implement dark mode", status: "todo", votes: 15 },
  { id: 2, title: "Add CSV export", status: "in-progress", votes: 10 },
  { id: 3, title: "Integrate with Slack", status: "done", votes: 8 },
  // ... add more mock ideas
]

export async function GET(request: NextRequest) {
  const authResult = authMiddleware(request)
  if (authResult) return authResult

  return NextResponse.json({ ideas: MOCK_IDEAS })
}

