import { type NextRequest, NextResponse } from "next/server"
import { authMiddleware } from "@/lib/auth"

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const authResult = authMiddleware(request)
  if (authResult) return authResult

  const id = params.id
  const { status } = await request.json()

  // Here you would update the idea in your database
  // For this example, we'll just return a success response
  return NextResponse.json({ success: true, id, newStatus: status })
}

