import { type NextRequest, NextResponse } from "next/server"
import { isAdmin } from "@/lib/auth"

export async function POST(request: NextRequest) {
  if (isAdmin(request)) {
    return NextResponse.json({ success: true })
  } else {
    return NextResponse.json({ success: false }, { status: 401 })
  }
}

