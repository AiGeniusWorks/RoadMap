import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { headers } from "next/headers"
import { prisma } from "@/lib/prisma"
import { authOptions } from "@/lib/auth"

export async function POST(req: Request, { params }: { params: { ideaId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const headersList = headers()
    const ip = headersList.get("x-forwarded-for") ?? "127.0.0.1"

    const vote = await prisma.vote.create({
      data: {
        ideaId: params.ideaId,
        authorId: session?.user?.id,
        ipAddress: !session ? ip : undefined,
      },
    })

    return NextResponse.json(vote)
  } catch (error) {
    console.error(error)
    return new NextResponse("Internal Error", { status: 500 })
  }
}

export async function DELETE(req: Request, { params }: { params: { ideaId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const headersList = headers()
    const ip = headersList.get("x-forwarded-for") ?? "127.0.0.1"

    await prisma.vote.deleteMany({
      where: {
        ideaId: params.ideaId,
        OR: [{ authorId: session?.user?.id }, { ipAddress: !session ? ip : undefined }],
      },
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    console.error(error)
    return new NextResponse("Internal Error", { status: 500 })
  }
}

