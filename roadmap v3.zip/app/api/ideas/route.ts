import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { authOptions } from "@/lib/auth"

const ideaSchema = z.object({
  title: z.string().min(1).max(100),
  description: z.string().min(1),
  email: z.string().email().optional(),
})

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)
    const json = await req.json()
    const body = ideaSchema.parse(json)

    const idea = await prisma.idea.create({
      data: {
        title: body.title,
        description: body.description,
        authorId: session?.user?.id,
        authorEmail: !session ? body.email : undefined,
      },
    })

    return NextResponse.json(idea)
  } catch (error) {
    console.error(error)
    return new NextResponse("Internal Error", { status: 500 })
  }
}

