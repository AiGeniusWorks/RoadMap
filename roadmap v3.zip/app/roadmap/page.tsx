import { RoadmapBoard } from "@/components/roadmap-board"

export default function RoadmapPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Roadmap</h1>
        <p className="text-muted-foreground">Track the progress of our feature development.</p>
      </div>
      <RoadmapBoard />
    </div>
  )
}

