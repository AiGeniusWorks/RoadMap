"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Idea {
  id: number
  title: string
  status: string
  votes: number
}

export default function AdminDashboard() {
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const router = useRouter()

  useEffect(() => {
    if (isAuthenticated) {
      fetchIdeas()
    }
  }, [isAuthenticated])

  const login = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Basic " + btoa(username + ":" + password),
      },
    })
    if (response.ok) {
      setIsAuthenticated(true)
      localStorage.setItem("adminAuth", "true")
    } else {
      toast({
        title: "Authentication failed",
        description: "Please check your credentials and try again.",
        variant: "destructive",
      })
    }
  }

  const fetchIdeas = async () => {
    const response = await fetch("/api/admin/ideas", {
      headers: {
        Authorization: "Basic " + btoa(username + ":" + password),
      },
    })
    if (response.ok) {
      const data = await response.json()
      setIdeas(data.ideas)
    }
  }

  const updateIdeaStatus = async (id: number, newStatus: string) => {
    const response = await fetch(`/api/admin/ideas/${id}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Basic " + btoa(username + ":" + password),
      },
      body: JSON.stringify({ status: newStatus }),
    })
    if (response.ok) {
      fetchIdeas()
      toast({
        title: "Status updated",
        description: `Idea ${id} status changed to ${newStatus}`,
      })
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <Card className="w-[350px]">
          <CardHeader>
            <CardTitle>Admin Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={login} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-5">Admin Dashboard</h1>
      <Card>
        <CardHeader>
          <CardTitle>Ideas Management</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Votes</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ideas.map((idea) => (
                <TableRow key={idea.id}>
                  <TableCell>{idea.id}</TableCell>
                  <TableCell>{idea.title}</TableCell>
                  <TableCell>{idea.status}</TableCell>
                  <TableCell>{idea.votes}</TableCell>
                  <TableCell>
                    <select
                      value={idea.status}
                      onChange={(e) => updateIdeaStatus(idea.id, e.target.value)}
                      className="border rounded p-1"
                    >
                      <option value="feedback">Feedback</option>
                      <option value="todo">To Do</option>
                      <option value="in-progress">In Progress</option>
                      <option value="done">Done</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

