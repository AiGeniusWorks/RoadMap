"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"

export default function UserSettings() {
  const [email, setEmail] = useState("")
  const [notifyOnComments, setNotifyOnComments] = useState(false)
  const [notifyOnStatusChange, setNotifyOnStatusChange] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send this data to your API
    toast({
      title: "Settings updated",
      description: "Your settings have been saved successfully.",
    })
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-5">User Settings</h1>
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>Manage your email and notification settings</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="notify-comments" checked={notifyOnComments} onCheckedChange={setNotifyOnComments} />
              <Label htmlFor="notify-comments">Notify me when someone comments on my idea</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="notify-status" checked={notifyOnStatusChange} onCheckedChange={setNotifyOnStatusChange} />
              <Label htmlFor="notify-status">Notify me when the status of my idea changes</Label>
            </div>
            <Button type="submit">Save Settings</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

