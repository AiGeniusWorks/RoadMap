import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const MOCK_ANNOUNCEMENTS = [
  {
    id: 1,
    title: "New Feature: Best Time to Post",
    date: "15 Oct, 2023",
    content:
      "We're excited to announce the launch of our new 'Best Time to Post' feature. This AI-powered tool analyzes your audience's activity patterns to suggest optimal posting times.",
  },
  {
    id: 2,
    title: "Upcoming Maintenance",
    date: "20 Oct, 2023",
    content:
      "We will be performing scheduled maintenance on October 25th from 2:00 AM to 4:00 AM UTC. During this time, the platform may experience brief periods of unavailability.",
  },
]

export default function AnnouncementsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Announcements</h1>
        <p className="text-muted-foreground">Stay updated with our latest news and feature releases.</p>
      </div>
      <div className="space-y-4">
        {MOCK_ANNOUNCEMENTS.map((announcement) => (
          <Card key={announcement.id}>
            <CardHeader>
              <CardTitle>{announcement.title}</CardTitle>
              <CardDescription>{announcement.date}</CardDescription>
            </CardHeader>
            <CardContent>
              <p>{announcement.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

