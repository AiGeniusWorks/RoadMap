import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { IdeaDetails } from "@/components/idea-details"
import { CommentSection } from "@/components/comment-section"

// This would come from your database
const MOCK_IDEA = {
  id: "197",
  title: "Best time to post",
  description:
    "Implement an AI-powered analytics feature that suggests the optimal posting times based on historical engagement data and audience activity patterns. This would help users maximize their content's reach and engagement by posting when their audience is most active.",
  votes: 18,
  status: "done",
  author: "Avareis",
  date: "5 Sep, 2021",
  updates: [
    {
      id: 1,
      date: "10 Sep, 2021",
      content: "We've started the initial research phase for this feature.",
      status: "in-progress",
    },
    {
      id: 2,
      date: "15 Oct, 2021",
      content: "Development is complete. The feature is now available in beta.",
      status: "done",
    },
  ],
}

export default function IdeaPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/ideas">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Feature Request Details</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          <IdeaDetails idea={MOCK_IDEA} />
          <CommentSection ideaId={MOCK_IDEA.id} />
        </div>
        <div className="space-y-6">
          <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
            <div className="p-6 space-y-4">
              <h3 className="font-semibold">Status Updates</h3>
              <div className="space-y-4">
                {MOCK_IDEA.updates.map((update) => (
                  <div key={update.id} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{update.date}</span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-medium
                        ${update.status === "done" ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"}`}
                      >
                        {update.status}
                      </span>
                    </div>
                    <p className="text-sm">{update.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

